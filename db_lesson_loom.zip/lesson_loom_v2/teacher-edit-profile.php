<?php 
include_once __DIR__ . '/header.php';
include_once __DIR__ . '/src/UserController.php';

// Initialize UserController instance
$userController = new UserController();
$teacherId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$response = $userController->getTeacherById($teacherId);

// Check if the retrieval was successful
if ($response['success']) {
    $teacher = $response['data'];
} else {
    $error = $response['error'];
}
?>  
<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Teacher Details</h5>
                    </div>
                    <div class="card-body">
                    <form method="POST" action="src/actions/UpdateTeacher.php" enctype="multipart/form-data">
					<?php if (isset($_SESSION['error_message'])): ?>
   				 		<div class="alert alert-danger">
							<?php 
								echo $_SESSION['error_message'];
								unset($_SESSION['error_message']); 
								?>
						</div>
					<?php endif; ?>

					<?php if (isset($_SESSION['success_message'])): ?>
						<div class="alert alert-success">
						<?php 
							echo $_SESSION['success_message'];
							unset($_SESSION['success_message']); 
							?>
						</div>
					<?php endif; ?>
					
					<input type="hidden" name="teacher_id" value="<?= htmlspecialchars($teacher['id']) ?>"> 
                            <div class="row">
                                <div class="col-sm-3">
                                    <label class="form-label text-primary">Photo<span class="required">*</span></label>
                                    <div class="avatar-upload">
										<div class="avatar-preview">
											<?php 
											// Set a default image if the teacher's photo is not available
											$photoUrl = !empty($teacher['photo']) ? "images/avatar/" . htmlspecialchars($teacher['photo']) : "images/avatar/1.jpg";
											?>
											<div id="imagePreview" style="background-image: url(<?= $photoUrl ?>); width: 16rem; height: 16rem;"></div>
										</div>
                                        <div class="change-btn mt-2 mb-lg-0 mb-3">
                                            <input type='file' class="form-control d-none" id="imageUpload" name="filename" accept=".png, .jpg, .jpeg">
                                            <label for="imageUpload" class="dlab-upload mb-0 btn btn-primary btn-sm">Choose File</label>
                                            <a href="javascript:void(0)" class="btn btn-danger light remove-img ms-2 btn-sm">Remove</a>
                                        </div>
                                    </div>    
                                </div>
                                <div class="col-sm-9">
                                    <div class="row">
                                        <div class="col-xl-4 col-sm-4">
                                            <div class="mb-3">
                                                <label for="firstname" class="form-label text-primary">First Name<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="firstname" placeholder="James" name="fname" value="<?= htmlspecialchars($teacher['fname']) ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-sm-4">
                                            <div class="mb-3">
                                                <label for="lastname" class="form-label text-primary">Last Name<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="lastname" placeholder="Doe" name="lname" value="<?= htmlspecialchars($teacher['lname']) ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-sm-4">
                                            <div class="mb-3">
                                                <label for="gender" class="form-label text-primary">Gender<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="gender" placeholder="Male" name="gender" value="<?= htmlspecialchars($teacher['gender']) ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-sm-6">
                                            <div class="mb-3">
                                                <label for="birthday" class="form-label text-primary">Birthday<span class="required">*</span></label>
                                                <input type="date" class="form-control" id="birthday" name="birthdate" value="<?= htmlspecialchars($teacher['birthdate']) ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-sm-6">
                                            <div class="mb-3">
                                                <label for="email" class="form-label text-primary">Email<span class="required">*</span></label>
                                                <input type="email" class="form-control" id="email" placeholder="example@domain.com" name="email" value="<?= htmlspecialchars($teacher['email']) ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-sm-6">
                                            <div class="mb-3">
                                                <label for="address" class="form-label text-primary">Address<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="address" placeholder="Address" name="address" value="<?= htmlspecialchars($teacher['address']) ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-sm-6">
                                            <div class="mb-3">
                                                <label for="phone" class="form-label text-primary">Contact<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="phone" placeholder="091237444" name="contact" value="<?= htmlspecialchars($teacher['contact']) ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-3 mt-3">
                                            <label class="text-label form-label">Upload ID<span class="required">*</span></label>
                                            <div action="#" class="dropzone">
                                                <div class="fallback">
                                                    <input name="photo" type="file" multiple>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-sm-12 mt-5">
                                            <div class="mb-3">
                                                <button class="btn btn-primary btn-sm float-end me-3" type="submit">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
        
<!--**********************************
    Content body end
***********************************-->

<div class="footer out-footer style-2">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="" target="_blank">LessonLoom</a> 2024</p>
    </div>
</div>

</div>
<!--**********************************
    Main wrapper end
***********************************-->

<!--**********************************
    Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="vendor/moment/moment.min.js"></script>
<script src="vendor/dropzone/dist/dropzone.js"></script>
<script src="vendor/bootstrap-datepicker-master/js/bootstrap-datepicker.min.js"></script>
<script src="vendor/wow-master/dist/wow.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/dlabnav-init.js"></script>
<script src="js/demo.js"></script>
<script src="js/styleSwitcher.js"></script>

<script>
    $(function () {
        $("#datepicker").datepicker({ 
            autoclose: true, 
            todayHighlight: true
        }).datepicker('update', new Date());
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                $('#imagePreview').hide();
                $('#imagePreview').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#imageUpload").change(function() {
        readURL(this);
    });

    $('.remove-img').on('click', function() {
        var imageUrl = "images/no-img-avatar.png";
        $('.avatar-preview, #imagePreview').removeAttr('style');
        $('#imagePreview').css('background-image', 'url(' + imageUrl + ')');
    });
</script>

</body>
</html>