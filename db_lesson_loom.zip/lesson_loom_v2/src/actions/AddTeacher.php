<?php
include_once "../UserController.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userController = new UserController();
    
    try {
        // Check if user is logged in and is admin (role = 1)
        if (!isset($_SESSION['login_data']) || $_SESSION['login_data']['role'] == 3) {
            throw new Exception("Unauthorized access");
        }

        // Call the UserController method
        $result = $userController->addTeacher($_POST);
        
        if ($result['success']) {
            $_SESSION['success_message'] = $result['message'];
            header('Location: ../../teacher.php');
            exit();
        } else {
            throw new Exception($result['error']);
        }

    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
        header('Location: ../../add-teacher.php');
        exit();
    }
}