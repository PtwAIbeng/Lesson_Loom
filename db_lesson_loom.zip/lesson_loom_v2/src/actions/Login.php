<?php
session_start();
include_once "../UserController.php";

$userController = new UserController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate input
    if (empty($email) || empty($password)) {
        $_SESSION['error_message'] = "Email and password are required.";
        header('location:../../index.php');
        exit();
    }

    // Attempt to log in
    $loginResult = $userController->login(['email' => $email, 'password' => $password]);

    if ($loginResult['success']) {
        // Redirect to a protected page
        header('location:../../dashboard.php');
        exit();
    } else {
        $_SESSION['error_message'] = $loginResult['error'];
        header('location:../../index.php');
        exit();
    }
}