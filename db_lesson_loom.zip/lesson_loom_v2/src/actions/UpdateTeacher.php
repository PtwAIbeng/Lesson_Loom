<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include_once "../UserController.php";
session_start();

// Initialize UserController instance
$userController = new UserController();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Collect data
        $request = [
            'teacher_id' => $_POST['teacher_id'] ?? null,
            'fname' => $_POST['fname'] ?? null,
            'lname' => $_POST['lname'] ?? null,
            'gender' => $_POST['gender'] ?? null,
            'birthdate' => $_POST['birthdate'] ?? null,
            'email' => $_POST['email'] ?? null,
            'address' => $_POST['address'] ?? null,
            'contact' => $_POST['contact'] ?? null,
            'filename' => $_FILES['filename'] ?? null,
        ];

        // Update teacher details
        $response = $userController->updateTeacher($request);

        // Validate the structure of $response
        if (!isset($response['success'])) {
            throw new Exception("Invalid response format.");
        }

        if ($response['success']) {
            // Redirect if successful
            header('Location: ../../teacher-edit-profile.php?id=' . urlencode($request['teacher_id']));
            exit();
        } else {
            // Handle failure with detailed error handling
            throw new Exception("Update failed: " . ($response['error'] ?? "Unexpected error during update."));
        }
    } catch (Exception $e) {
        // Log the error and redirect to an error page
        error_log("Error: " . $e->getMessage());
        header('Location: ../../error-page.php?message=' . urlencode($e->getMessage()));
        exit();
    }
}
?>