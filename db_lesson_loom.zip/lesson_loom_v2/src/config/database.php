<?php  
include_once "const.php";
include_once "compiler.php";

class Database extends Compiler {
    protected $hostname = DB_HOSTNAME;
    protected $username = DB_USERNAME;
    protected $password = DB_PASSWORD;
    protected $dbname   = DB_NAME;
    protected $conn;

    public function __construct() {
        $this->conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
    }
    
    public function status() {
        if(!$this->conn) return mysqli_error($this->conn);
        else return 'Success';
    }

    public function connect() {
        return $this->conn;
    }

    public function closed() {
        return mysqli_close($this->conn);
    }

    // New method to execute a query and return results as an array
    public function find_array($sql) {
        $result = mysqli_query($this->conn, $sql);
        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    }

    // New method to count the number of rows returned by a query
    public function count_num($sql) {
        $result = mysqli_query($this->conn, $sql);
        return mysqli_num_rows($result);
    }

    // New method to safely escape strings for SQL queries
    public function str_injector($str) {
        return mysqli_real_escape_string($this->conn, $str);
    }
}
?>