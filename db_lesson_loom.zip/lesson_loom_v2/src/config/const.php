<?php
    define('DB_HOSTNAME', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', 'db_lesson_loom');

    define('USER_ROLE_ADMIN', 1);
    define('USER_ROLE_SCHOOL', 2);
    define('USER_ROLE_TEACHER', 3);

    define('ONLINE', 1);
    define('OFFLINE', 0);
?>