<?php
    include_once 'config/database.php';

    class UserController extends Database {

        public function user_role() {
            $result = array('success' => false);

            try {
                $sql = "SELECT * FROM user_role";
                $count = $this->count_num($sql);
                $data = $this->find_array($sql);

                if ($count > 0) {
                    $result = array(
                        'success' => true,
                        'data' => $data
                    );
                }

            } catch(\Exception $e) {
                $result['error'] = $e->getMessage();
            }

            return $result;
        }

        public function addTeacher($request) {
            $result = array('success' => false);
        
            try {
                // Validate required fields
                $requiredFields = ['school_id', 'fname', 'lname', 'email', 'password'];
                foreach ($requiredFields as $field) {
                    if (empty($request[$field])) {
                        throw new Exception("All fields marked with * are required");
                    }
                }
        
                // Sanitize input
                $schoolId = $this->str_injector($request['school_id']);
                $firstName = $this->str_injector($request['fname']);
                $lastName = $this->str_injector($request['lname']);
                $email = $this->str_injector($request['email']);
                $password = $request['password'];
        
                // Validate email format
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception("Invalid email format");
                }
        
                // Check if email already exists
                $checkEmail = "SELECT id FROM users WHERE email = '$email'";
                if ($this->count_num($checkEmail) > 0) {
                    throw new Exception("Email already exists");
                }
        
                // Begin transaction
                $connection = $this->connect();
                mysqli_begin_transaction($connection);
        
                // Insert into teachers table
                $teacherSql = "INSERT INTO teachers (school_id, fname, lname, status) VALUES (?, ?, ?, ?)";
                $teacherStmt = mysqli_prepare($connection, $teacherSql);
                $status = 1;
                
                mysqli_stmt_bind_param($teacherStmt, "issi", $schoolId, $firstName, $lastName, $status);
        
                if (!mysqli_stmt_execute($teacherStmt)) {
                    throw new Exception("Error creating teacher record: " . mysqli_error($connection));
                }
        
                $teacherId = mysqli_insert_id($connection);
        
                // Insert into users table
                $userSql = "INSERT INTO users (user_role, teacher_id, email, password, status) VALUES (?, ?, ?, ?, ?)";
                $userStmt = mysqli_prepare($connection, $userSql);
                $userRole = 3; // Teacher role
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $userStatus = 1;
                
                mysqli_stmt_bind_param($userStmt, "iissi", $userRole, $teacherId, $email, $hashedPassword, $userStatus);
        
                if (!mysqli_stmt_execute($userStmt)) {
                    throw new Exception("Error creating user account: " . mysqli_error($connection));
                }
        
                mysqli_commit($connection);
                
                $result['success'] = true;
                $result['message'] = "Teacher added successfully!";
        
            } catch (Exception $e) {
                if (isset($connection)) {
                    mysqli_rollback($connection);
                }
                $result['error'] = $e->getMessage();
            } finally {
                if (isset($teacherStmt)) mysqli_stmt_close($teacherStmt);
                if (isset($userStmt)) mysqli_stmt_close($userStmt);
            }
        
            return $result;
        }


    // Function to get all teachers
    public function getAllTeachers() {
        $result = array('success' => false);
        
        try {
            $sql = "
                SELECT t.*, u.email 
                FROM teachers AS t
                JOIN users AS u ON t.id = u.teacher_id 
                WHERE t.status = 1 AND u.status = 1"; // Ensuring both teacher and user are active
            
            $data = $this->find_array($sql);
            $result['success'] = true;
            $result['data'] = $data;
        } catch (\Exception $e) {
            $result['error'] = $e->getMessage();
        }
    
        return $result;
    }

    // Function to get a teacher by ID
    public function getTeacherById($teacherId) {
        $result = array('success' => false);
    
        try {
            $sql = "
                SELECT t.*, u.email 
                FROM teachers AS t
                JOIN users AS u ON t.id = u.teacher_id 
                WHERE t.id = ? AND t.status = 1 AND u.status = 1"; // Ensuring both teacher and user are active
            
            $connection = $this->connect();
            $stmt = mysqli_prepare($connection, $sql);
            mysqli_stmt_bind_param($stmt, "i", $teacherId);
            mysqli_stmt_execute($stmt);
            $query_result = mysqli_stmt_get_result($stmt);
            $teacher = mysqli_fetch_assoc($query_result);
    
            if ($teacher) {
                $result['success'] = true;
                $result['data'] = $teacher;
            } else {
                $result['error'] = "Teacher not found or inactive.";
            }
        } catch (\Exception $e) {
            $result['error'] = $e->getMessage();
        }
    
        return $result;
    }

    public function searchTeachers($searchTerm) {
        $result = array('success' => false);
    
        try {
            $sql = "
                SELECT t.*, u.email 
                FROM teachers AS t
                JOIN users AS u ON t.id = u.teacher_id 
                WHERE (t.fname LIKE ? OR t.lname LIKE ? OR u.email LIKE ?) 
                AND t.status = 1 AND u.status = 1";
    
            $searchTerm = '%' . $searchTerm . '%';
            $connection = $this->connect();
            $stmt = mysqli_prepare($connection, $sql);
            mysqli_stmt_bind_param($stmt, "sss", $searchTerm, $searchTerm, $searchTerm);
            mysqli_stmt_execute($stmt);
            $query_result = mysqli_stmt_get_result($stmt);
            $teachers = mysqli_fetch_all($query_result, MYSQLI_ASSOC);
    
            if ($teachers) {
                $result['success'] = true;
                $result['data'] = $teachers;
            } else {
                $result['error'] = "No teachers found.";
            }
        } catch (\Exception $e) {
            $result['error'] = $e->getMessage();
        }
    
        return $result;
    }
    public function updateTeacher($request) {
        $result = ['success' => false]; // Default response
    
        try {
            if (empty($request['teacher_id'])) {
                throw new Exception("Teacher ID is required.");
            }
    
            $connection = $this->connect();
            mysqli_begin_transaction($connection);
    
            // Check if the email already exists in the users table
            if (!empty($request['email'])) {
                $emailCheckSql = "SELECT COUNT(*) FROM users WHERE email = ? AND id != ?";
                $emailCheckStmt = mysqli_prepare($connection, $emailCheckSql);
                if (!$emailCheckStmt) {
                    throw new Exception("Failed to prepare email check statement: " . mysqli_error($connection));
                }
                mysqli_stmt_bind_param($emailCheckStmt, "si", $request['email'], $request['teacher_id']);
                mysqli_stmt_execute($emailCheckStmt);
                mysqli_stmt_bind_result($emailCheckStmt, $emailCount);
                mysqli_stmt_fetch($emailCheckStmt);
                mysqli_stmt_close($emailCheckStmt);
    
                if ($emailCount > 0) {
                    throw new Exception("The email address " . $request['email'] . " is already in use.");
                }
            }
    
            // Build SQL dynamically for the teacher update
            $teacherSql = "UPDATE teachers SET ";
            $params = [];
            $types = "";
    
            if (!empty($request['fname'])) {
                $teacherSql .= "fname = ?, ";
                $params[] = $this->str_injector($request['fname']);
                $types .= "s";
            }
            if (!empty($request['lname'])) {
                $teacherSql .= "lname = ?, ";
                $params[] = $this->str_injector($request['lname']);
                $types .= "s";
            }
            if (!empty($request['gender'])) {
                $teacherSql .= "gender = ?, ";
                $params[] = $this->str_injector($request['gender']);
                $types .= "s";
            }
            if (!empty($request['birthdate'])) {
                $teacherSql .= "birthdate = ?, ";
                $params[] = $this->str_injector($request['birthdate']);
                $types .= "s";
            }
            if (!empty($request['contact'])) {
                $teacherSql .= "contact = ?, ";
                $params[] = $this->str_injector($request['contact']);
                $types .= "s";
            }
            if (!empty($request['address'])) {
                $teacherSql .= "address = ?, ";
                $params[] = $this->str_injector($request['address']);
                $types .= "s";
            }
    
            // Handle the email update
            if (!empty($request['email'])) {
                $teacherSql .= "email = ?, ";
                $params[] = $this->str_injector($request['email']);
                $types .= "s";
            }
    
            // Handle uploaded photo
            if (!empty($request['photo']) && $request['photo']['error'] === UPLOAD_ERR_OK) {
                $uploadedPhotoPath = $this->handle_profile_upload($request['photo'], $request['teacher_id']);
                $teacherSql .= "photo = ?, ";
                $params[] = $uploadedPhotoPath;
                $types .= "s";
            }
    
            // Remove trailing comma and add WHERE clause
            $teacherSql = rtrim($teacherSql, ", ") . " WHERE id = ?";
            $params[] = $request['teacher_id'];
            $types .= "i";
    
            if (strlen($types) > 1) {
                $teacherStmt = mysqli_prepare($connection, $teacherSql);
    
                // Bind parameters dynamically
                $bindParams = [];
                $bindParams[] = &$types; // Add types by reference
                foreach ($params as $key => $value) {
                    $bindParams[] = &$params[$key]; // Add each param by reference
                }
    
                if (!call_user_func_array('mysqli_stmt_bind_param', array_merge([$teacherStmt], $bindParams))) {
                    throw new Exception("Error binding parameters: " . mysqli_stmt_error($teacherStmt));
                }
    
                if (!mysqli_stmt_execute($teacherStmt)) {
                    throw new Exception("Error updating teacher record: " . mysqli_error($connection));
                }
            }
    
            // Commit transaction
            mysqli_commit($connection);
            $result['success'] = true; // Indicate successful update
        } catch (Exception $e) {
            if (isset($connection)) {
                mysqli_rollback($connection);
            }
            $result['error'] = $e->getMessage();
            error_log("UpdateTeacher Error: " . $e->getMessage());
        } finally {
            if (isset($teacherStmt)) {
                mysqli_stmt_close($teacherStmt);
            }
            if (isset($connection)) {
                mysqli_close($connection);
            }
        }
    
        return $result;
    }
    public function login($request) {
        $result = array('success' => false);
    
        try {
            $email = $this->str_injector($request['email']);
            $password = $this->str_injector($request['password']);
    
            // SQL query to fetch user data
            $sql = "SELECT 
                        user.id, user.user_role, user.email, user.fname, user.lname, user.password,
                        (CASE
                            WHEN user.user_role = 1 THEN 'Admin'
                            WHEN user.user_role = 2 THEN 'School'
                            WHEN user.user_role = 3 THEN 'Teacher'
                        END) AS role_name
                    FROM 
                        users user
                    WHERE 
                        user.email = ? 
                        AND user.status = 1";
    
            $connection = $this->connect();
            $stmt = mysqli_prepare($connection, $sql);
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            $query_result = mysqli_stmt_get_result($stmt);
            $user = mysqli_fetch_assoc($query_result);
    
            if (!$user) {
                throw new Exception("No user found with this email or account is inactive.");
            }
    
            // For testing: Password comparison
            if ($user && password_verify($password, $user['password'])) {
                throw new Exception("Invalid password.");
            }
    
            // Set session data
            $_SESSION['login_data'] = [
                'user_id' => $user['id'],
                'role' => $user['user_role'],
                'role_name' => $user['role_name'],
                'email' => $user['email'],
                'fname' => $user['fname'],
                'lname' => $user['lname']
            ];
    
            $result = array(
                'success' => true,
                'data' => $user
            );
    
        } catch (Exception $e) {
            $result['error'] = $e->getMessage();
        }
    
        return $result;
    }
        
        public function register($request) {
            $result = array('success' => false);
        
            try {
                // Validate required fields
                $requiredFields = ['school_id', 'school_name', 'school_acronym', 'email', 'phone', 'address', 'password', 'confirm_password'];
                foreach ($requiredFields as $field) {
                    if (empty($request[$field])) {
                        throw new Exception("All fields are required");
                    }
                }
        
                // Sanitize input
                $schoolId = $this->str_injector($request['school_id']);
                $schoolName = $this->str_injector($request['school_name']);
                $schoolAcronym = $this->str_injector($request['school_acronym']);
                $email = $this->str_injector($request['email']);
                $phone = $this->str_injector($request['phone']);
                $address = $this->str_injector($request['address']);
                $password = $request['password'];
                $confirmPassword = $request['confirm_password'];
        
                // Validate email format
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception("Invalid email format");
                }
        
                // Check if email already exists
                $checkEmail = "SELECT id FROM users WHERE email = '$email'";
                if ($this->count_num($checkEmail) > 0) {
                    throw new Exception("Email already exists");
                }
        
                // Check if passwords match
                if ($password !== $confirmPassword) {
                    throw new Exception("Passwords do not match");
                }
        
                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
                // Begin transaction
                $connection = $this->connect();
                mysqli_begin_transaction($connection);
        
                // First, insert into schools table
                $schoolSql = "INSERT INTO schools (sch_id, sch_name, sch_acro, sch_address, sch_contact, sch_status) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                
                $schoolStmt = mysqli_prepare($connection, $schoolSql);
                $schoolStatus = 1;
                
                mysqli_stmt_bind_param($schoolStmt, "sssssi", 
                    $schoolId, 
                    $schoolName, 
                    $schoolAcronym, 
                    $address,
                    $phone,
                    $schoolStatus
                );
        
                if (!mysqli_stmt_execute($schoolStmt)) {
                    throw new Exception("Error creating school record: " . mysqli_error($connection));
                }
        
                $schoolInsertId = mysqli_insert_id($connection);
        
                // Then, insert into users table
                $userSql = "INSERT INTO users (user_role, school_id, email, password, status) 
                            VALUES (?, ?, ?, ?, ?)";
                            
                $userStmt = mysqli_prepare($connection, $userSql);
                $userRole = 2; // School role
                $userStatus = 1;
                
                mysqli_stmt_bind_param($userStmt, "iissi", 
                    $userRole,
                    $schoolInsertId,
                    $email,
                    $hashedPassword,
                    $userStatus
                );
        
                if (!mysqli_stmt_execute($userStmt)) {
                    throw new Exception("Error creating user account: " . mysqli_error($connection));
                }
        
                $userId = mysqli_insert_id($connection);
        
                // Handle file upload
                if (isset($_FILES['certificate']) && $_FILES['certificate']['error'] === UPLOAD_ERR_OK) {
                    $this->handle_certificate_upload($_FILES['certificate'], $userId);
                }
        
                // Commit transaction
                mysqli_commit($connection);
                
                $result['success'] = true;
                $result['message'] = "Registration successful!";
        
            } catch (Exception $e) {
                // Rollback transaction if there was an error
                if (isset($connection)) {
                    mysqli_rollback($connection);
                }
                $result['error'] = $e->getMessage();
            } finally {
                if (isset($schoolStmt)) {
                    mysqli_stmt_close($schoolStmt);
                }
                if (isset($userStmt)) {
                    mysqli_stmt_close($userStmt);
                }
            }
        
            return $result;
        }
        
        private function handle_file_upload($file, $userId, $fileType) {
            try {
                // Determine target directory based on file type
                $targetDir = ($fileType === 'certificate') ? "uploads/certificates/" : "uploads/photos/";
                
                // Create directory if it doesn't exist
                if (!is_dir($targetDir)) {
                    if (!mkdir($targetDir, 0755, true)) {
                        throw new Exception("Failed to create upload directory");
                    }
                }
        
                // Set allowed types based on file type
                $allowedTypes = ($fileType === 'certificate') 
                    ? ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png']
                    : ['jpg', 'jpeg', 'png'];
                    
                $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                
                if (!in_array($fileExtension, $allowedTypes)) {
                    throw new Exception("Invalid file type. Allowed types: " . implode(", ", $allowedTypes));
                }
        
                // Validate file size (max 5MB)
                if ($file['size'] > 5 * 1024 * 1024) {
                    throw new Exception("File size too large. Maximum size is 5MB");
                }
        
                // Generate unique filename
                $fileName = uniqid() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", $file['name']);
                $targetPath = $targetDir . $fileName;
        
                // Move uploaded file
                if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
                    throw new Exception("Failed to upload file");
                }
        
                // Save file record in database
                $connection = $this->connect();
                $sql = "INSERT INTO file_uploads (resources_id, resources_type, filename) VALUES (?, ?, ?)";
                $stmt = mysqli_prepare($connection, $sql);
                
                if (!$stmt) {
                    throw new Exception("Failed to prepare statement: " . mysqli_error($connection));
                }
        
                mysqli_stmt_bind_param($stmt, "iss", $userId, $fileType, $targetPath);
                
                if (!mysqli_stmt_execute($stmt)) {
                    throw new Exception("Failed to save file record: " . mysqli_stmt_error($stmt));
                }
        
                mysqli_stmt_close($stmt);
                return true;
        
            } catch (Exception $e) {
                // If there's an error, attempt to delete the uploaded file
                if (isset($targetPath) && file_exists($targetPath)) {
                    unlink($targetPath);
                }
                throw $e;
            }
        }
        
        // Helper methods to make the code more readable
        private function handle_certificate_upload($file, $userId) {
            return $this->handle_file_upload($file, $userId, 'certificate');
        }
        
        private function handle_profile_upload($file, $userId) {
            return $this->handle_file_upload($file, $userId, 'photo');
        }

        public function getSchools() {
            try {
                $sql = "SELECT id, sch_name FROM schools WHERE sch_status = 1 ORDER BY sch_name";
                return $this->find_array($sql);
            } catch (Exception $e) {
                error_log("Error fetching schools: " . $e->getMessage());
                return [];
            }
        }
        public function update($request) {
            $result = array('success' => false);

            try {
                $set_clauses = [];

                if (isset($request['last_active_flg']) && $request['last_active_flg']) {
                    $set_clauses[] = "last_active_date = NOW()";
                }

                if (isset($request['is_online_flg'])) {
                    $set_clauses[] = "is_online_flg = " . $request['is_online_flg'];
                }

                $set_clause = implode(", ", $set_clauses);

                $query = "UPDATE users SET $set_clause WHERE id = $request[user_id]";
                $updated = $this->save($query);

                if ($updated) {
                    $result['success'] = true;
                }

            } catch(\Exception $e) {
                $result['error'] = $e->getMessage();
            }

            return $result;
        }
    }
?>