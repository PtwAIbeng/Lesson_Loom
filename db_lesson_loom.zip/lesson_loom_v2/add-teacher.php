<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Debug session data
if (isset($_GET['debug'])) {
    echo '<pre>';
    print_r($_SESSION);
    echo '</pre>';
}

// Check if user is logged in
if (!isset($_SESSION['login_data'])) {
    $_SESSION['error_message'] = "Please log in to continue.";
    header('Location: index.php');
    exit();
}

// Check if user is admin (role = 1)
if (!isset($_SESSION['login_data']['role']) || $_SESSION['login_data']['role'] == 3) {
    $_SESSION['error_message'] = "Unauthorized access.";
    header('Location: index.php');
    exit();
}

include_once __DIR__ . '/header.php';
include_once __DIR__ . '/src/UserController.php';

$userController = new UserController();
$isAdminOrSchool = true; // We already verified admin status above

// Check if user is logged in
if (!isset($_SESSION['login_data'])) {
    $_SESSION['error_message'] = "Please log in to continue.";
    header('Location: login.php');
    exit();
}

?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <form action="src/actions/AddTeacher.php" method="POST">

        <?php if (isset($_SESSION['error_message'])): ?>
   				 		<div class="alert alert-danger">
							<?php 
								echo $_SESSION['error_message'];
								unset($_SESSION['error_message']); 
								?>
						</div>
					<?php endif; ?>

					<?php if (isset($_SESSION['success_message'])): ?>
						<div class="alert alert-success">
						<?php 
							echo $_SESSION['success_message'];
							unset($_SESSION['success_message']); 
							?>
						</div>
					<?php endif; ?>
            <div class="row">
            <?php if ($isAdminOrSchool): ?>
                <div class="col-xl-12">
                    <div class="mb-3">
                        <label for="school_id" class="form-label text-primary">Select School<span class="required">*</span></label>
                        <select class="form-control" id="school_id" name="school_id" required>
                            <option value="">Select School</option>
                            <?php
                            // Fetch schools from database
                            $schools = $userController->getSchools();  // You'll need to create this method
                            foreach ($schools as $school): ?>
                                <option value="<?php echo $school['id']; ?>">
                                    <?php echo htmlspecialchars($school['sch_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            <?php endif; ?>
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Teacher Details</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xl-6 col-sm-6">
                                    <div class="mb-3">
                                        <label for="fname" class="form-label text-primary">First Name<span class="required">*</span></label>
                                        <input type="text" class="form-control" id="fname" name="fname" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="lname" class="form-label text-primary">Last Name<span class="required">*</span></label>
                                        <input type="text" class="form-control" id="lname" name="lname" required>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-sm-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label text-primary">Email<span class="required">*</span></label>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label text-primary">Password<span class="required">*</span></label>
                                        <input type="password" class="form-control" id="password" name="password" required>
                                    </div>
                                </div>
                            </div>
                            <div class="float-end">
                                <button class="btn btn-primary" type="submit">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!--**********************************
    Content body end
***********************************-->

<div class="footer out-footer style-2">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2023</p>
    </div>
</div>

<!--**********************************
    Footer end
***********************************-->

<!--**********************************
   Support ticket button start
***********************************-->

<!--**********************************
   Support ticket button end
***********************************-->

</div>
<!--**********************************
    Main wrapper end
***********************************-->

<!--**********************************
    Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/dlabnav-init.js"></script>
<script src="js/demo.js"></script>
<script src="js/styleSwitcher.js"></script>

<script>

   
</script>

</body>
</html>