<?php
// Include necessary files
include_once __DIR__ . '/header.php';
require_once 'src/UserController.php';

// Initialize UserController instance
$userController = new UserController();

// Check if a search term is provided
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
$response = $searchTerm ? $userController->searchTeachers($searchTerm) : $userController->getAllTeachers();

// Check if the retrieval was successful
if ($response['success']) {
    $teachers = $response['data'];
} else {
    $error = $response['error'];
}
?>
		
<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="page-title flex-wrap">
                <form method="GET" action="">
                    <div class="input-group mb-md-0 mb-3">
                        <input type="text" name="search" class="form-control" placeholder="Search" value="<?= htmlspecialchars($searchTerm) ?>" />
                        <?php if ($searchTerm): // Only show the clear button if there is a search term ?>
                            <a href="teacher.php" class="btn btn-outline-secondary" title="Clear Search">✖</a>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-outline-primary" data-mdb-ripple-init>Search</button>
                    </div>
                </form>
                    <div>
                        <button type="button" class="btn btn-primary" onclick="window.location.href='add-teacher.php'">
                            + New Teacher
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-xl-12">
                <div class="table-responsive full-data">
                    <table class="table table-responsive-lg dataTablesCard student-tab">
                        <thead>
                            <tr>
                                <th>Teacher ID</th>
                                <th>Teacher Name</th>
                                <th>Email</th>
                                <th>Teacher Address</th>
                                <th>Teacher Contact</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($teachers)): ?>
                                <?php foreach ($teachers as $teacher): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($teacher['id']) ?></td>
                                        <td><?= isset($teacher['fname']) ? htmlspecialchars($teacher['fname']) . ' ' . htmlspecialchars($teacher['lname']) : 'N/A' ?></td>
                                        <td><?= htmlspecialchars($teacher['email']) ?></td>
                                        <td><?= htmlspecialchars($teacher['address']) ?></td>
                                        <td><?= htmlspecialchars($teacher['contact']) ?></td>
                                        <td>
                                            <span class="badge light badge-<?= $teacher['status'] === 'active' ? 'success' : 'danger' ?>">
                                                <?= ucfirst(htmlspecialchars($teacher['status'])) ?>
                                            </span>
                                        </td>
                                        <td><?= isset($teacher['created']) ? date('F d, Y', strtotime($teacher['created'])) : 'N/A' ?></td>
                                        <td>
                                            <a class="btn btn-info" href="teacher-detail.php?id=<?= $teacher['id'] ?>">View</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">No teachers found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
	
        <!--**********************************
            Content body end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->
		
        <!--**********************************
           Support ticket button end
        ***********************************-->


        </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

<?php include_once __DIR__ . '/footer.php'; ?>
